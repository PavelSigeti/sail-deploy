<template>
    <h1>Упс, а что ты тут делаешь ?</h1>
</template>

<script>
export default {
    name: "NotFound"
}
</script>

<style scoped>

</style>
